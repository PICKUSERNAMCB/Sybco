<?php
// src/Controller/GroupeController.php
namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\product\Group ;
use App\Repository\product\GroupeRepository ;
use App\Entity\Famille ;
use App\Entity\updateFamille ;
use App\Form\GroupeType ;
use App\Form\updateGroupeType ; 
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use App\Pagin\PaginApp ;




class GroupeController extends AbstractController
{
 

  
    public function __construct(Group $group, GroupeRepository $List, PaginApp $pagin) 
    {
        $this->Group = $group ;
        $this->GroupeRepository = $List ;
        $this->PaginApp = $pagin ;
    }
    
   /**
    * 
    * @Route("/fichiergroupe", name="readgroupe" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function List(): Response
    {
        return $this->Pagin('asc', 3, 0);
    }

   /**
    * @Route("/groupepagin/ascdesc/{ascdesc}/limit/{limit}/offset/{offset}" ,  name="groupepagin",  methods={"GET"})
    */
    public function Pagin($ascdesc, $limit, $offset)    
    {   
        return $this->render('listgroupe.html.twig', array(
              'groupes' => $this
                  ->GroupeRepository
                  ->findAllPagin($ascdesc, $limit, $offset), 
              'pagin' => $this
                 ->PaginApp
                 ->Pagin("/groupepagin", $ascdesc, $limit, $offset, $this
                             ->GroupeRepository
                             ->findByCountId()
                         ),
              'ErrorException' => NULL           
              )
         );
    }

   /**
    * @Route("/form/nouveaugroupe")
    * @Security("is_granted('ROLE_USER')")
    */
    public function Create(Request $request, $ErrorException = NULL, $groupe = NULL): Response
    {
        
        $famille = new Famille();
        $form = $this->createForm(GroupeType::class, $famille); 
        $form->handleRequest($request) ;  
        if ($form->isSubmitted() && $form->isValid()) 
        {
             $ErrorException = $this->Group->Create($famille);
             if ($ErrorException == 0) 
             {
                  return $this->redirect($request->getUri()) ;
             }
        }
        return $this->render('nouveaugroupe.html.twig', array(
            'form' => $form->createView(),
            'ErrorException'  => $ErrorException 
        ));
    }
    
   /**
    * 
    * @Route("/updategroupe/idgroupe/{idgroupe} ", name="testgroupe" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function Update(Request $request, $idgroupe, $ErrorException = NULL): Response
    {
        $updatefamille = new updateFamille();
        $form = $this->createForm(updateGroupeType::class, $updatefamille); 
        $form->handleRequest($request) ;  
        $groupes = $this
                     ->GroupeRepository
                     ->findFileGroupeById($idgroupe);
        foreach($groupes as $groupe) 
        {
            $id = $groupe->getId() ;
            $groupe = $groupe->getGroup() ; 
        }
        if ($form->isSubmitted() && $form->isValid()) 
        {
              $ErrorException = $this->Group->update($updatefamille, $idgroupe);
              if ($ErrorException == 0) 
              {
                  return $this->redirectToRoute('editgroupe', ['idgroupe' => $idgroupe]);
              } 
        }
        return $this->render('updategroupe.html.twig', 
                               array('form' => $form->createView(),
                                     'ErrorException'  => $ErrorException,
                                     'Groupe' => $groupe
                                     ));
    }    

   /**
    * 
    * @Route("/editiongroupe/idgroupe/{idgroupe} ", name="editgroupe" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function Editgroupe(Request $request, $idgroupe): Response
    {
        /* $Groupe = explode("=>", $lessergroupe->getGroupe())[1] ;*/
        return $this->render('editgroupe.html.twig', array(
          'groupes' => $this->GroupeRepository->findFileGroupeByid($idgroupe) 
          ));
    }    
}





