<?php
// src/Controller/ProductController.php
namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\Article;
use App\Form\ArticleType; 
use App\Form\updateArticleType ;
use App\Form\updateArticle ; 
use App\Form\ImageType ;
use App\Form\Image ;
use App\Repository\product\ProductReferency ;
use App\Repository\product\ProdRepository ;
use App\Repository\config\TvaRepository ;
use App\Repository\product\EtiquetteRepository ;
use App\Repository\fournisseur\FournisseurRepository ; 
use App\Repository\config\Config ;
use App\Pagin\PaginApp ;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;







class ProductController extends AbstractController
{
    
   

    
    public function __construct(ProductReferency $ref, PaginApp $app, ProdRepository $pr, EtiquetteRepository $er, TvaRepository $tr, FournisseurRepository $fr,
        Config $cf)
    {
        $this->ProductReferency = $ref ;
        $this->TvaRepository = $tr ;
        $this->FournisseurRepository = $fr ;
        $this->PaginApp = $app ;
        $this->ProdRepository = $pr ;
        $this->EtiquetteRepository = $er ;
        $this->Config = $cf ;
    }
      
      
   /**
    *
    * @Route("/form/nouveauproduit")
    * @Security("is_granted('ROLE_USER')")
    *
    */
    public function Create(Request $request, $ErrorException = NULL): Response
    {
        $article = new Article();
        $form = $this->createForm(ArticleType::class, $article); 
        $form->handleRequest($request) ;  
        // formulaire validation
        if ($form->isSubmitted() && $form->isvalid()) 
        {
            // si aucune erreur n'est détectée après validation
            $ErrorException = $this->ProductReferency->CreateRef($article, $form, $request) ;
            if ($ErrorException == -1) 
            {
                echo "<script>alert('Erreur syst\351me !')</script>" ;  
                } else {
                          if($ErrorException == 0) 
                          {
                              return $this->redirectToRoute('app_product_create');
                          }
                }
        }      
       //  création du formulaire et renvoi avec le tableau à 2 dimension value et error
        return $this->render('nouveauproduit.html.twig', array(
          'form' => $form->createView(),
          'ErrorException'  => $ErrorException,
          'descriptioncomplete' => $request->request->get("descriptioncomplete"),
          'GTIN' => $article->getCode()
        ));             
    }

   /**
    * 
    * @Route("/fichierproduit", name="read" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function List(): Response
    {
        return $this->Pagin('asc', 3, 0);
    }
    
    
   /**
    * @Route("/productpagin/ascdesc/{ascdesc}/limit/{limit}/offset/{offset}" ,  name="productpagin",  methods={"GET"})
    */
    public function Pagin($ascdesc, $limit, $offset)    
    {   
        return $this->render('listprod.html.twig', array(
              'articles' => $this
                  ->ProdRepository
                  ->ProdOnlyRead($ascdesc, $limit, $offset), 
              'pagin' => $this
                 ->PaginApp
                 ->Pagin("/productpagin", $ascdesc, $limit, $offset, $this
                             ->ProdRepository
                             ->findByCountId()
                         ),
              'ErrorException' => NULL           
              )
         );
    }
  
   /**
    * 
    * @Route("/updateproduit/idproduct/{idproduct} ", name="update" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function Update(Request $request, $idproduct, $ErrorException = NULL, $gtin = NULL): Response
    {
        $updatearticle = new updateArticle();
        $form = $this->createForm(updateArticleType::class, $updatearticle); 
        $form->handleRequest($request) ;  
        $prodArray = $this->ProdRepository->ArrayBeforUpdating($idproduct) ;
        if ($form->isSubmitted() && $form->isvalid()) 
        {
            $gtin = $updatearticle->getCode();    
            $ErrorException = $this
                               ->ProductReferency
                               ->UpdateRef($updatearticle, $form, $request, $idproduct, $prodArray['Avis']) ;
            if ($ErrorException == 1) 
            {
                echo "<script>alert('Erreur syst\351me !')</script>" ;  
                } else {
                        if( $ErrorException == 0 ) 
                        {
                           return $this->redirectToRoute('edit', ['idproduct' => $idproduct]);
                        } 
                }    

        }              
        //  création du formulaire et renvoi avec les tableaux à 2 dimensions value et error
        return $this->render('updateproduit.html.twig', array(
                                                         'form' => $form->createView(),
                                                         'ErrorException'  => $ErrorException,
                                                         'GTIN' => $gtin,
                                                         'prod' => $prodArray,
                                                         'etiquettes' => $this
                                                                       ->EtiquetteRepository
                                                                       ->findByList(),
                                                         'fournisseurs' => $this
                                                                       ->FournisseurRepository
                                                                       ->findByList(),
                                                         'taxes' => $this
                                                                       ->TvaRepository
                                                                       ->findByList(),
                                                         'stocks' => $this->Config->stockConfig() ,
                                                         'done' => 1
                                                          ));
        
    }    
    
    
   /**
    * 
    * 
    * @Route("/updateimage/idproduct/{idproduct} ", name="updateimg" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function UpdateImg(Request $request, $idproduct, $ErrorException = NULL): Response
    {
        $image = new Image();
        $form = $this->createForm(ImageType::class, $image); 
        $form->handleRequest($request) ;  
        
        $produits = $this->ProdRepository->findFileProductById($idproduct);
        // formulaire validation
        if ($form->isSubmitted() && $form->isvalid()) 
        {
            $ErrorException = $this
                               ->ProductReferency
                               ->updateImage($form, $produits[0]->getGTIN() ,$produits[0]->getMiniatureUrl(), $request) ;
            if ($ErrorException == -1) 
            {
                echo "<script>alert('Erreur syst\351me !')</script>" ;  
                } else {
                        if( $ErrorException == 0 ) 
                        {
                            return $this->redirectToRoute('edit', ['idproduct' => $idproduct]);
                        } 
                }    
        }              
        //  création du formulaire et renvoi avec les tableaux à 2 dimensions value et error
        return $this->render('updateimage.html.twig', array(
          'form' => $form->createView(),
          'ErrorException'  => $ErrorException,
          'id' => $idproduct,
          'MiniatureUrl' => $produits[0]->getMiniatureUrl()  
                            
        ));             
    }    


   /**
    * 
    * @Route("/editionproduit/idproduct/{idproduct} ", name="edit" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function Edit(Request $request, $idproduct): Response
    {
       
        //  création du formulaire et renvoi avec le tableau à 2 dimension value et error
        return $this->render('editproduit.html.twig', array(
          'prod' =>  $this->ProdRepository->ArrayBeforUpdating($idproduct) 
            ));
      }    
}
