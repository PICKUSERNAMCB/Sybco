<?php
// src/Controller/LesserGroupController.php
namespace App\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\EtiquetteType; 
use App\Form\Sfamille ; 
use App\Form\updateSFamille ;
use App\Form\updateEtiquetteType ; 
use App\Repository\product\LesserGroup ;
use App\Repository\product\EtiquetteRepository ;
use App\Pagin\PaginApp ;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;



class LesserGroupController extends AbstractController
{
    
   

    
    public function __construct(LesserGroup $lesser, EtiquetteRepository $er, PaginApp $pa)
    {
        $this->LesserGroup = $lesser ;
        $this->EtiquetteRepository = $er ;
        $this->PaginApp = $pa ;
    }

   /**
    * 
    * @Route("/fichierlessergroupe", name="readlessergroupe" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function List(): Response
    {
        return $this->Pagin('asc', 5, 0);
    }

   /**
    * @Route("/lessergroupepagin/ascdesc/{ascdesc}/limit/{limit}/offset/{offset}" ,  name="lessergroupepagin",  methods={"GET"})
    */
    public function Pagin($ascdesc, $limit, $offset)    
    {   
        $lessergroupes = $this->EtiquetteRepository->findAllPagin($ascdesc, $limit, $offset);
        return $this->render('listlessergroupe.html.twig', array(
              'lessergroupes' => $lessergroupes,
              'pagin' => $this
                 ->PaginApp
                 ->Pagin("/lessergroupepagin", $ascdesc, $limit, $offset, $this
                             ->EtiquetteRepository
                             ->findByCountId()
                         ),
              'ErrorException' => NULL           
              )
         );
    }

   /**
    *
    * @Route("/form/nouveletiquette")
    * @Security("is_granted('ROLE_USER')")
    *
    */
    public function Create(Request $request, $ErrorException = NULL): Response
    {
        $sfamille = new Sfamille();
        $form = $this->createForm(EtiquetteType::class, $sfamille); 
        $form->handleRequest($request) ;  
        // formulaire validation
        if ($form->isSubmitted() && $form->isvalid()) 
        {
            $ErrorException = $this->LesserGroup->CreateLesserGroup($sfamille) ;
            if ($ErrorException == -1) 
            {
              echo "<script>alert('Erreur syst\351me !')</script>" ;  
                 } else {
                          if($ErrorException == 0) 
                          {
                              return $this->redirectToRoute('app_lessergroup_new');
                          }
                }
        }      
        //  création du formulaire et renvoi avec le tableau à 2 dimension value et error
        return $this->render('nouveletiquette.html.twig', array(
          'form' => $form->createView(),
          'ErrorException' => $ErrorException
           ));             
    }
    
    
   /**
    * 
    * @Route("/updatelessergroupe/idlessergroupe/{idlessergroupe} ", name="updategroupe" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function Update(Request $request, $idlessergroupe, $ErrorException = NULL): Response
    {   
        $updatefamille = new updateSFamille();
        $form = $this->createForm(updateEtiquetteType::class, $updatefamille); 
        $form->handleRequest($request) ;   
        // ORM
        $lessergroupes = $this
                       ->EtiquetteRepository
                       ->findFileLesserGroupeById($idlessergroupe);
        foreach($lessergroupes as $lessergroupe) 
        {
            $id = $lessergroupe->getId() ;
            $groupe = explode("=>", $lessergroupe->getGroupe())[1] ;
            $etiquette = $lessergroupe->getEtiquette() ;
        }
        
        //$LesserGroupeisSubmitted = $updatesfamille->getEtiquette();    
        if ($form->isSubmitted() && $form->isValid()) 
        {
              $ErrorException = $this->LesserGroup->update($updatefamille, $idlessergroupe);
              if ($ErrorException == 0) 
              {
                  return $this->redirectToRoute('editlessergroupe', ['idlessergroupe' => $idlessergroupe]);
                         
              } 
        }
        /*if($LesserGroupeisSubmitted != NULL ) 
        {
            $LessergroupeUpdate = $LesserGroupeisSubmitted ;
        }*/
            
        return $this->render('updateetiquette.html.twig', array(
          'form' => $form->createView(),
          'Groupe' => $groupe,
          'Etiquette' => $etiquette,
          'ErrorException' =>$ErrorException 
           ));             
    }    

    
    
    

   /**
    * 
    * @Route("/editionlessergroupe/idlessergroupe/{idlessergroupe} ", name="editlessergroupe" )
    * @Security("is_granted('ROLE_USER')")
    * 
    */
    public function EditLessergroupe(Request $request, $idlessergroupe): Response
    {
        /* $Groupe = explode("=>", $lessergroupe->getGroupe())[1] ;*/
        return $this->render('editlessergroupe.html.twig', array(
          'lessergroupes' => $this->EtiquetteRepository->findFileLesserGroupeByid($idlessergroupe)
          ));             
    }    
    
}
