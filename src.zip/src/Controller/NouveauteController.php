<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class NouveauteController extends AbstractController
{
    
 
   /**
     * @Route("/nouveaute")
     */
    public function nouveaute(): Response
    {
        return $this->render('nouveaute2.html.twig');
    }
    
}