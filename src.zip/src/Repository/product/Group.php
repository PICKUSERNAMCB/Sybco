<?php
namespace App\Repository\product ;
use Doctrine\ORM\EntityManagerInterface ;
use App\Entity\Groupe ; 
use App\Repository\product\GroupeRepository ;  



class Group   
{
    private $em ;
    public function __construct(EntityManagerInterface $em, GroupeRepository $groupe) 
    {
        $this->em = $em;
        $this->GroupeRepository = $groupe ;
    }

    
   
   /**
    * @return 
    */
    public function Update($updategroupe, $idgroupe)
    {
    
        if ( $this->GroupeRepository->findOneGroupeBefUpdate(
                                  $updategroupe->getGroupe(), 
                                  $idgroupe) != 1)
        {
           try {
            
            $groupe = $this->GroupeRepository->findOneBySomeField($id) ;
            $groupe->setGroup($updategroupe->getGroupe());
            $this->em->flush();
            } catch (Exception $e) {
                      return 1 ; //$e->getMessage()
                }
        return 0 ;    
            
        }
    }
    
    
   /**
    *  
    */   
    public function Create($group) 
    { 
  	    if( $this->GroupeRepository->findOneGroupe($group->getGroupe()) != 1) 
  	    {
        	  try {
  	                $groupe = new Groupe ;
                    $groupe->setGroup($group->getGroupe()) ;
                    $this->em->persist($groupe) ;
                    $this->em->flush() ;
                  } catch (Exception $e) {
                      return -1 ; //$e->getMessage()
                      } 
  	         return 0 ;
  	         } else {
                 return 1 ;
  	    }
  	}
}    
        