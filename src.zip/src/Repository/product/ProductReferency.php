<?php
// src\Repository\product\ProductReferency.php
namespace App\Repository\product ;
use Doctrine\ORM\EntityManagerInterface ;
use App\Repository\product\ProdRepository ;
use App\Repository\product\EtiquetteRepository ;
use App\Repository\config\TvaRepository ;
use App\Repository\fournisseur\FournisseurRepository ;
use App\Entity\Prod ; 


class ProductReferency   
{
    private $em ;
    
    public function __construct(EntityManagerInterface $em, ProdRepository $prod, EtiquetteRepository $eq, TvaRepository $tva, 
    FournisseurRepository $fe) 
    {
        $this->em = $em;
        $this->ProdRepository = $prod ;
        $this->EtiquetteRepository = $eq ;
        $this->TvaRepository = $tva ;
        $this->FournisseurRepository = $fe ;
    }

   /**
    * @return 
    */
    public function PreText($descriptioncomplete): string 
    {
        return substr($descriptioncomplete, 0, 70);  
    }

   /**
    * @return 
    */
   	public function VerifyAvis($article): int 
    {
        if($article->getAvis() != true ) 
        {
          return -1 ;
        } else 
           {
             return  0 ;
            } 
    }
    
   /**
    * @return 
    */
   	public function NewAvis($updatearticle, $lastAvis): int 
    {
  	    if($updatearticle->getAvis() == true) 
  	    {
          if($lastAvis == 0) 
          {
              return -1;
          } else {
                 return 0 ;
                 }
              } else {
                   return $lastAvis  ;
                } 
    }

   /**
    * DataBase Abstraction Layer 
    * insertion dans la table produit
    * anti injection par emploi de la méthode insert
    */   
    public function InputProduct($article, $miniature_url, $descriptioncomplete): int 
    {     
        return $this->insert($article, 
                             $this
                               ->VerifyAvis($article), 
                             $this
                               ->Pretext(
                             $descriptioncomplete), 
                             $miniature_url, 
                             $descriptioncomplete) ;
    }    

   /**
    * DataBase Abstraction Layer 
    * upadte dans la table produit
    * anti injection par emploi de la méthode update
    */   
    public function UpdateProduct($updatearticle, $descriptioncomplete, $request, $id, $lastAvis): int 
    {     
        return $this
                ->newproduct($updatearticle, 
                             $this
                                ->NewAvis($updatearticle, $lastAvis), 
                             $this
                                ->Pretext($descriptioncomplete), 
                             /*$miniature_url,*/ 
                             $descriptioncomplete,
                             $request,
                             $id);
    }    
    
   /**
    * @return 
    */
    private function newproduct($updatearticle, $Avis, $pretext, $descriptioncomplete, $request, $id): int
    {
        try {
            
            $prod = $this->ProdRepository->findOneBySomeField($id) ;
            $prod->setEtiquette($this->EtiquetteRepository->findOneBySomeField($request->request->get("etiquette")));
            $prod->setFournisseur($this->FournisseurRepository->findOneBySomeField($request->request->get("fournisseur")));
            $prod->setTypeTva($this->TvaRepository->findOneBySomeField($request->request->get("typetva")));
            $prod->setDescription($updatearticle->getDescription()) ;
            $prod->setStock($request->request->get("stock")) ;
            $prod->setPrixTTC($updatearticle->getPrixTTC()) ;
            $prod->setGTIN($updatearticle->getCode()) ;
            $prod->setPretext($pretext);
            $prod->setDescriptionComplete($descriptioncomplete);
            $prod->setAvis($Avis);
            $this->em->flush();
            } catch (Exception $e) {
                      return 1 ; //$e->getMessage()
                }
        return 0 ;
      
    }

   
   /**
    * @insert a product   
    */
    public function insert($article, $Avis, $pretext, $miniature_url, $descriptioncomplete): ?int
    {
                    
        try 
            {            
              $prod = new Prod ;
              $prod->setEtiquette($this->EtiquetteRepository->findOneBySomeField($article->getEtiquette()));
              $prod->setFournisseur($this->FournisseurRepository->findOneBySomeField($article->getFournisseur()));
              $prod->setTypeTva($this->TvaRepository->findOneBySomeField($article->getTva()));
              $prod->setDescription($article->getDescription()) ;
              $prod->setStock($article->getStock()) ;
              $prod->setPrixTTC($article->getPrixTTC()) ;
              $prod->setGTIN($article->getCode()) ;
              $prod->setPretext($pretext);
              $prod->setDescriptionComplete($descriptioncomplete);
              $prod->setAvis($Avis);
              $prod->setMiniatureUrl($miniature_url);
              $prod->setNbrAvis(0);
              $this->em->persist($prod) ;
              $this->em->flush() ;
              } catch (Exception $e) {
                      return -1 ; //$e->getMessage()
                } 
        return 0 ; 
    }
    
   /**
    * @return 
    */
    public function ControlMessage($produit)
    { 
      
        //valeurs déjà enregistrée renvoyer Error (non à null)
        $gtins = $this->ProdRepository->findOneGtin($produit->getCode()) ;
        $gtinMatch = NULL ;
        foreach($gtins as $gtin) 
        {
           $gtinMatch = $gtin->getGTIN() ;
        }
        if($gtinMatch != NULL ) 
        { 
            if( $produit->getCode() == $gtinMatch ) 
            {
                return 3 ;
             } 
         }
         if($produit->getControlCode() != false) 
         {
            //gestion de la clef GTIN
            //modulo GTIN si incorrect renvoyer Error (non à null) 
            if( $produit->getCode() != NULL ) 
            {  
                if($this->isValidBarcode($produit->getCode() )!= 1) 
                {
                   return 4 ;
                }
            }     
          }
          return 0 ;
    }
    
   /**
    * @return 
    */
    public function UpdateMessage($updateproduit, $idproduct)
    { 
        $gtins = $this->ProdRepository->findOneGtin($updateproduit->getCode()) ;
        $gtinMatch = NULL ;
        foreach($gtins as $gtin) 
        {
            $gtinMatch = $gtin->getGTIN() ;
            $id = $gtin->getId();
        }
        if( $gtinMatch != NULL) 
        {
            if( $id != $idproduct) 
            {
                return 3 ;
            } 
        }
        if($updateproduit->getControlCode() != false) 
        {
           //gestion de la clef GTIN
           //modulo GTIN si incorrect renvoyer Error (non à null) 
           if( $updateproduit->getCode() != NULL ) 
           {  
               if($this->isValidBarcode($updateproduit->getCode() )!= 1) 
               {
                   $error['GTIN'] = "Le code ".$updateproduit->getCode()." est erroné !" ;
                   return 4 ;
                }
           }     
        }
        return 0 ;
    }
  
   /**
    * @return 
    */
    public function isValidBarcode($barcode) 
    {
        //checks validity of: GTIN-8, GTIN-12, GTIN-13, GTIN-14, GSIN, SSCC
        //see: http://www.gs1.org/how-calculate-check-digit-manually
        $barcode = (string) $barcode;
        //we accept only digits
        if (!preg_match("/^[0-9]+$/", $barcode)) {
           return false;
        }
        //check valid lengths:
        $l = strlen($barcode);
        if(!in_array($l, [8,12,13,14,17,18]))
           return false;
        //get check digit
        $check = substr($barcode, -1);
        $barcode = substr($barcode, 0, -1);
        $sum_even = $sum_odd = 0;
        $even = true;
        while(strlen($barcode)>0) {
            $digit = substr($barcode, -1);
            if($even)
                $sum_even += 3 * $digit;
            else 
                $sum_odd += $digit;
            $even = !$even;
            $barcode = substr($barcode, 0, -1);
        }
        $sum = $sum_even + $sum_odd;
        $sum_rounded_up = ceil($sum/10) * 10;
        return ($check == ($sum_rounded_up - $sum));
    }

   /**
    * @return 
    */
    public function ImgManag($article, $miniature_url, $form, $verifyMiniature)
    {
       
        try { 
              $form
                ->get('miniature')
                ->getData()
                ->move("produits", $miniature_url);
              return $Image = $this
                               ->VerifySxSy(['gtin' => $article
                                                        ->getCode()], 
                                              $verifyMiniature);
            } catch (Exception $e) {
                return -1 ;                                         
            }              
           
    }
    
   /**
    * @return int
    */
    public function VerifySxSy($key, $verifyMiniature)
    {
        list($width, $height, $type, $attr) = getimagesize($verifyMiniature);
        if($width >= $height + ($height/10)) 
        {
            return $this->Stderr($key, NULL) ;
        }
        if($height >= $width + ($width/2)) 
        {
            return $this->Stderr($key, NULL) ;
        }
        if($width < 200) /*200*/ 
        {
            return $this->Stderr($key, NULL);
        }
        if($width > 1600)
        {
           return $this->Stderr($key, NULL);
        }
        if($height < 200)
        {
           return $this->Stderr($key, NULL);
        }
        if($height > 1600)
        {
           return $this->Stderr($key, NULL);
        }
        return 0 ;
    }
   /**
    * @return int
    */
    public function ImgUpdateVerify($verifyMiniature)
    {
        list($width, $height, $type, $attr) = getimagesize($verifyMiniature);
        if($width >= $height + ($height/10)) 
        {
            return 1 ; 
        }
        if($height >= $width + ($width/2)) 
        {
            return 1 ;
        }
        if($width < 200) /*200*/ 
        {
            return 1 ; 
        }
        if($width > 1600)
        {
           return 1 ;
        }
        if($height < 200)
        {
            return 1 ; 
        }
        if($height > 1600)
        {
            return 1 ;
        }
        return 0 ;
    }
    
   /**
    * @return 
    */
    public function Stderr($key, $error)
    {
        // on a le "code de  l'image" on peut updater
        // en cas d'echec on aura la possibilité de renvoyer un code image
        // les info erreur insertion et update sont dispo  dans un journal
        // ici il existe la possibilité d'inscrire une erreur de traitement image  
        try {
             $this
                ->ProdRepository
                ->Update(['miniature_url' => "/produits/produit.jpg"], $key) ;
            // gestion de l'erreur en journalisation
        
            } catch (Exception $e) {
                return 2 ;                                         
            }             
       return 1 ;
    }
          
   /**
    * @return 
    */
    public function CreateRef($article, $form, $request)
    {
        // si aucune erreur n'est détectée après validation 
        $ErrorException = $this->ControlMessage($article) ;
        // 0 xor 2 xor 3
        if($ErrorException == 0) 
        { 
           if( $article->getControlCode() == false) 
           {
               $codeImage = str_replace(' ' ,'', $article->getCode());
               } else {
                     $codeImage = $article->getCode();
                    }
           // création de la data url img  
           $miniature_url = "produits/".$codeImage.'.'.$form
                        ->get('miniature')
                        ->getData()
                        ->guessExtension();
           $verifyMiniature = $miniature_url ;
           $miniature_url = "/".$miniature_url ;
           // 0 xor 1
           if($ErrorException = $this
                              ->InputProduct($article, $miniature_url, $request
                              ->request
                              ->get("descriptioncomplete")) != 1) 
           {
              // ou valeur positive EE
              // 0 xor 4  xor 5
              $ErrorException = $this->ImgManag($article, $miniature_url, $form, $verifyMiniature) ;
           } 
        }    
        // cas 0 xor 2 xor 3
        // cas 0 xor 1
        // cas 0 xor 4 xor 5                             
        return $ErrorException ;
    }  
   
   /**
    * @return 
    */
    public function UpdateRef($updatearticle, $form, $request, $id, $lastAvis)
    {
        // si aucune erreur n'est détectée après validation 
        $ErrorException = $this->UpdateMessage($updatearticle, $id) ;
        // 0 xor 2 xor 3
        if($ErrorException == 0) 
        {
            // 0 xor 1
            $ErrorException = $this
                        ->UpdateProduct($updatearticle, /*$miniature_url,*/ $request
                        ->request
                        ->get("descriptioncomplete"), $request,  $id, $lastAvis)  ; 
        
        }
        // cas 0 xor 2 xor 3
        // cas 0 xor 1
        // cas 0 xor 4 xor 5                              
        return $ErrorException ;
    }
        
   /**    
    * @return 
    */
    public function UpdateImage($form, $gtin, $miniature_url, $request)
    {
        // transfert de nom et récupération de l'extension
        $codeImage = str_replace(' ' ,'', $gtin);
        $miniature_url = "produits/".$codeImage.'.'.$form
                        ->get('miniature')
                        ->getData()
                        ->guessExtension();
        // déplacement du fichier img vers le répertoire produits                
        $form
            ->get('miniature')
            ->getData()
            ->move("produits", $miniature_url);
        // si dimensions ok                 
        $ErrorException = $this->ImgUpdateVerify($miniature_url) ; 
        // sinon suppression du fichier et remplacement par image par défaut .
        if($ErrorException == 1)
        {
            $this
               ->ProdRepository
               ->Update(['miniature_url' => "/produits/produit.jpg"], ['gtin' => $gtin]) ;
            } else {
                    $this
                       ->ProdRepository
                       ->Update(['miniature_url' => "/".$miniature_url], ['gtin' => $gtin]) ;
                  }
        return $ErrorException ;                   
    }

}  






