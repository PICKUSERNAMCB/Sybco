<?php
namespace App\Repository\product ;
use Doctrine\ORM\EntityManagerInterface ;
use App\Entity\Etiquette ; 
use App\Repository\product\GroupeRepository ;

class LesserGroup   
{
    private $em ;
    public function __construct(EntityManagerInterface $em, EtiquetteRepository $er, GroupeRepository $groupe) 
    {
        $this->em = $em;
        $this->EtiquetteRepository = $er ;
        $this->GroupeRepository = $groupe ;
    }

   /*
    * @return int
    */
    public function updateLessergroupe($etiquette, $id): int
    {
      try {
            
            $lessergroupe = $this->EtiquetteRepository->findOneBySomeField($id) ;
            $lessergroupe->setEtiquette($etiquette);
            $this->em->flush();
            } catch (Exception $e) {
                      return 1 ; //$e->getMessage()
                }
        return 0 ;
    }

   /**
    * @return 
    */
    public function Update($updatelessergroupe, $idlessergroupe)
    {
        if( $this->EtiquetteRepository->findOneEtiquetteByGroupeBefUpdate(
                                  $updatelessergroupe->getGroupe(), 
                                  $updatelessergroupe->getEtiquette(), 
                                  $idlessergroupe) != 1)
        {
            // 0 xor 1*/
            return  $this
                        ->updateLessergroupe($updatelessergroupe->getEtiquette(), $idlessergroupe)  ; 
        }
        return -1 ; 
    }
    
    
   /*
    * @return 
    *
    */ 
    protected function insert($lessergroup)
    {
        // 0 xor 2 xor 3
        if( $this->EtiquetteRepository->findOneEtiquetteByGroupe(
                                  $lessergroup->getGroupe(), 
                                  $lessergroup->getEtiquette()) 
                                  != 1)
        {
           try {
                 $etiquette = new Etiquette ;
                 $etiquette->setEtiquette($lessergroup->getEtiquette()) ;
                 $etiquette->setGroupe($this->GroupeRepository->findOneBySomeField($lessergroup->getGroupe())) ;
                 $this->em->persist($etiquette) ;
                 $this->em->flush() ;
              } catch (Exception $e) {
                      return -1 ; //$e->getMessage()
                } 
           return 0 ;
           } else {
              return 1 ; 
        }
        
    }


   	
    public function CreateLesserGroup($lessergroup)
    {
        return $this->insert($lessergroup) ; 
    }
}    
    
    
    