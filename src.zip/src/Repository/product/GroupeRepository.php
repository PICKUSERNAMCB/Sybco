<?php
namespace App\Repository\product;
use App\Entity\Groupe;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\ORM\EntityManagerInterface ;




/**
 * @method Tva|null find($id, $lockMode = null, $lockVersion = null)
 * @method Tva|null findOneBy(array $criteria, array $orderBy = null)
 * @method Tva[]    findAll()
 * @method Tva[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class GroupeRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry, EntityManagerInterface $em)
    {
        parent::__construct($registry, Groupe::class);
        $this->em = $em;
    }
    

    // /**
    //  * @return Groupe[] Returns an array of Groupe objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('g')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('g.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */
   
    public function findOneBySomeField($value): ?Groupe
    {
        return $this->createQueryBuilder('g')
            ->andWhere('g.id = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    
   /**
    * @return count id
    */
    public function findByCountId(): int
    {
        return $this->createQueryBuilder('g')
             ->select('count(g.id)')
             ->getQuery()
             ->getSingleScalarResult();
    }   
    
    public function findByList(): array
    {
        return $this->createQueryBuilder('g')
            ->getQuery()
            ->getResult()
        ;
    }
    
   /**
    * @return Groupe[] Returns an array of Groupe objects
    */
    public function findOneGroupe($groupe)
    {
        return $this->createQueryBuilder('groupe')
            ->select('count(groupe.id)') 
             ->andWhere('groupe.groupe = :val')
             ->setParameter('val', $groupe)
             ->getQuery()
             ->getSingleScalarResult()
            ;
    }
    
    
    public function findOneGroupeBefUpdate($groupe, $idgroupe): int
    {
       return $this->createQueryBuilder('groupe')
            ->select('count(groupe.id)') 
            ->andWhere('groupe.groupe = :val')
            ->andWhere('groupe.id != :val2')
            ->setParameter('val', $groupe)
            ->setParameter('val2', $idgroupe)
            ->getQuery()
            ->getSingleScalarResult();
    }
    
    
   /**
    * Doctrine 
    * retourne un array derniers sous groupe enregistrés
    */
    public function findByLastgroupInsert(): array 
    {
        $count = $this->findByCountId() ;
        $offset = $count - 30 ;
        if($offset < 0) {
            $offset = 0; 
        }
        $limit = $offset + 30 ;
        
        return $this->createQueryBuilder('g')
            ->orderBy('g.id', 'ASC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
     }

    
    public function findAllPagin($ascdesc, $limit, $offset): array
    {
        return $this->createQueryBuilder('groupe')
            ->orderBy('groupe.id', 'ASC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }
                    
   
   /**
    * @return count id
    */
    public function findByhomeCountId($etiquette): int
    {
        return $this->createQueryBuilder('p')
             ->select('count(p.id)')
             ->andWhere('p.etiquette = :val')
             ->setParameter('val', $etiquette)
             ->getQuery()
             ->getSingleScalarResult();
    }
    
   /**
    *  
    * retourne un tableau issue d'une requête sur groupe
    */
    public function findFileGroupeById($idgroupe): array 
    {
        return $this->createQueryBuilder('groupe')            
            ->andWhere('groupe.id = :val')
            ->setParameter('val', $idgroupe)
            ->getQuery()
            ->getResult()
            ;
            
    }
    
    public function findByListTen(): array
    {   
        return $this->createQueryBuilder('groupe')
                 ->setMaxResults(10)
                 ->getQuery()
                 ->getResult();
    }
    
    
    
    public function findOneGroupeById($idgroupe): string
    {
        $groupes = $this->createQueryBuilder('g')
                 ->andWhere('g.id = :val')
                 ->setParameter('val', $idgroupe) 
                 ->getQuery()
                 ->getResult();
        return $groupes[0]->getGroup() ;      
     }
 
    
    
    
    
    
}
