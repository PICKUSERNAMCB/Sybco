<?php
namespace App\Repository\product;
use App\Entity\Etiquette;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\ORM\EntityManagerInterface ;



/**
 * @method Etiquette|null find($id, $lockMode = null, $lockVersion = null)
 * @method Etiquette|null findOneBy(array $criteria, array $orderBy = null)
 * @method Etiquette[]    findAll()
 * @method Etiquette[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class EtiquetteRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry, EntityManagerInterface $em)
    {
        $this->em = $em ;
        parent::__construct($registry, Etiquette::class);
    }

    // /**
    //  * @return Etiquette[] Returns an array of Etiquette objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    
    public function findOneBySomeField($value): ?Etiquette
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.id = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }

    public function findByList(): array
    {
        return $this->createQueryBuilder('e')
            ->getQuery()
            ->getResult()
        ;
    }
    
    public function findByListMaxResult($max): array
    {
        return $this->createQueryBuilder('e')
            ->setMaxResults($max) 
            ->getQuery()
            ->getResult()
        ;
    }
    
    public function findById($id): array
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.id = :val')
            ->setParameter('val', $id)
            ->getQuery()
            ->getResult()
            
        ;
    }

   /**
    * @return count id
    */
    public function findByCountId(): int
    {
        return $this->createQueryBuilder('e')
             ->select('count(e.id)')
             ->getQuery()
             ->getSingleScalarResult();
    }   

    public function findOneEtiquetteByGroupeBefUpdate($idgroupe, $etiquette, $idlessergroupe): int
    {
       
       
       return $this->createQueryBuilder('etiquette')
            ->select('count(etiquette.id)') 
            ->Join('etiquette.groupe', 'etiquette_groupe')
            ->andWhere('etiquette.etiquette = :val')
            ->andWhere('etiquette_groupe.groupe = :val2')
            ->andWhere('etiquette.id != :val3')
            ->setParameter('val', $etiquette)
            ->setParameter('val2', $idgroupe)
            ->setParameter('val3', $idlessergroupe) 
            ->getQuery()
            ->getSingleScalarResult();
        ;
    }
    
       
    public function findOneEtiquetteByGroupe($etiquette, $idgroupe)
    {
       return $this->createQueryBuilder('etiquette')
            ->select('count(etiquette.id)') 
            ->Join('etiquette.groupe', 'etiquette_groupe')
            ->andWhere('etiquette.etiquette = :val')
            ->andWhere('etiquette_groupe.groupe = :val2')
            ->setParameter('val', $etiquette)
            ->setParameter('val2', $idgroupe)
            ->getQuery()
            ->getSingleScalarResult();
        ;
    }

    public function findAllPagin($ascdesc, $limit, $offset): array
    {
        return $this->createQueryBuilder('etiquette')
            ->Join('etiquette.groupe', 'etiquette_groupe')
            ->orderBy('etiquette.id', 'ASC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }
                    
   /**
    * 
    * retourne un tableau issue d'une requête sur relation etiquette/groupe
    */
    public function findFileLesserGroupeById($idlessergroupe): array 
    {
        return $this->createQueryBuilder('etiquette')            
            ->Join('etiquette.groupe', 'etiquette_groupe')
            ->andWhere('etiquette.id = :val')
            ->setParameter('val', $idlessergroupe)
            ->getQuery()
            ->getResult()
            ;
            
    }
    
   /**
    * Doctrine 
    * retourne un array derniers sous groupe enregistrés
    */
    public function findByLastLesserGroupInsert(): array 
    {
        $count = $this->findByCountId() ;
        $offset = $count - 30 ;
        if($offset < 0) {
            $offset = 0; 
        }
        $limit = $offset + 30 ;
        
        return $this->createQueryBuilder('e')
            ->orderBy('e.id', 'ASC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
     }

   /**
    ** @return $arrayName = array('' => );
    */   
    public function Read(): array 
    {
        return $this->createQueryBuilder('etiquette')            
            ->Join('etiquette.groupe', 'etiquette_groupe')
            ->getQuery()
            ->getResult()
            ;
            
    }

    public function PrintEtiquetteByGroup($idgroupe, $DescAsc, $EndOffset): array // front
    {               
      return $this->createQueryBuilder('etiquette')
             ->Join('etiquette.groupe', 'g')
             ->orderBy('etiquette.id', $DescAsc)
             ->andWhere('g.id = :val')
             ->setParameter('val', $idgroupe)
             ->setMaxResults($EndOffset)
             ->getQuery()
             ->getResult();    
    }
 
}
