<?php
namespace App\Repository\front;
use App\Repository\product\ProdRepository ;
use App\Repository\product\EtiquetteRepository ; 
use App\Repository\product\GroupeRepository ;

class FrontRepository
{
    
    
    public function __construct(ProdRepository $prod, EtiquetteRepository $etiquette, GroupeRepository $groupe)
    {
        $this->ProdRepository = $prod ; 
        $this->EtiquetteRepository = $etiquette ;
        $this->GroupeRepository = $groupe ;
    }   
    
    
   /**
    *  doctrine
    */
    public function ReadFront($ascdesc, $limit, $offset): array
    {
        return $this->ProdRepository->Read($ascdesc, $limit, $offset);
    }

    public function findOneProductFront($id)
    {
        return $this->ProdRepository->findOneProduct($id) ;
    }
    
    public function LastArticleFront($DescAsc): array // front
    {
        return $this->ProdRepository->LastArticle($DescAsc) ; 
    }

    public function findByListFront(): array
    {   
        return $this->GroupeRepository->findByListTen();
    }

    public function findOneGroupeByIdFront($idgroupe): string
    {
       return $this->GroupeRepository->findOneGroupeById($idgroupe) ; 
    }

    public function SearchProductFront($description): ?array
    {
        return $this->ProdRepository->SearchProduct($description) ;
    }
    
    public function DescriptionReadFront($description, $DescAsc, $EndOffset, $BaseOffset): array 
    {
        return $this->ProdRepository->DescriptionRead($description, $DescAsc, $EndOffset, $BaseOffset); 
    }
    
    public function findReadbyGroupeFront($idgroupe, $DescAsc, $EndOffset, $BaseOffset): array  // front
    {
        return $this->ProdRepository->findReadbyGroupe($idgroupe, $DescAsc, $EndOffset, $BaseOffset);
    }
    
    public function findReadbyEtiquetteFront($idetiquette, $DescAsc, $EndOffset, $BaseOffset): array // front
    {
        return $this->ProdRepository->findReadbyEtiquette($idetiquette, $DescAsc, $EndOffset, $BaseOffset);
    } 

    public function findByCountByGroupeFront($idgroupe): int
    {  
        return $this->ProdRepository->findByCountByGroupe($idgroupe);
    }   

    public function findByCountIdParamEtiquetteFront($idetiquette): int // front
    {
        return $this->ProdRepository->findByCountIdParamEtiquette($idetiquette) ;
    }
    
    public function PrintEtiquetteByGroupFront($idgroupe, $DescAsc, $EndOffset): array // front
    {   
        return $this->EtiquetteRepository->PrintEtiquetteByGroup($idgroupe, $DescAsc, $EndOffset) ;
    } 

    public function findByCountByDescriptionFront($description): int
    {
        return $this->ProdRepository->findByCountByDescription($description) ;
    } 

    public function findReadbyProductFront($description, $DescAsc, $limit, $offset): array 
    {
        return $this->ProdRepository->findReadbyProduct($description, $DescAsc, $limit, $offset) ;    
    }    
}
