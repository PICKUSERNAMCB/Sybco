<?php
namespace App\Repository;
use Doctrine\ORM\EntityManagerInterface ;




class UserPrefRepository 
{
  
   public function __construct(EntityManagerInterface $em) 
   {
        $this->em = $em;
   }
  
  
   /**
    * DataBase Abstraction Layer 
    * retourne un tableau issue d'une requête sur table produit
    */
    public function FindByEmail($email)
    {
        // le projet DQL n'est plus maintenu 
        // en présence de requêtes complexes on utilise le retour à SQL
        return $this->em
                ->getConnection()
                ->executeQuery('SELECT '.
                               '  *    '.
                               ' FROM  '.
                               ' '.strtolower('User'.'_'.'Pref').
                               ' WHERE email =  ?',
                    array($email)    
                    )
                ->fetchAll();
    }


}
