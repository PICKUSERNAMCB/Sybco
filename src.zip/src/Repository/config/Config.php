<?php
namespace App\Repository\config ;



class Config 
{
   /**
    * interessant dans le cas ou on recherche un prod en liste 
    */   
    public function stockConfig() 
    {
    
        $stocks = array();
        for($i = 0 ; $i < 300 ; $i++)
        {
            $stocks[$i] = $i ;
        }
        return $stocks ;
        
    }
}       
