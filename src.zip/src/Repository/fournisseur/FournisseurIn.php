<?php
namespace App\Repository\fournisseur ;
use Doctrine\ORM\EntityManagerInterface ;
use App\Entity\fournisseur ; 
use App\Repository\fournisseur\FournisseurRepository ;  



class FournisseurIn   
{
    private $em ;
    public function __construct(EntityManagerInterface $em, FournisseurRepository $fournisseur) 
    {
        $this->em = $em;
        $this->FournisseurRepository = $fournisseur ;
    }

       
   /**
    * @return 
    */
    public function Update($updatefournisseur, $idfournisseur)
    {
    
        if ( $this->FournisseurRepository->findOneFournisseurBefUpdate(
                                  $updatefournisseur->getNom(), 
                                  $idfournisseur) != 1)
        {
           try {
            
            $fournisseur = $this->FournisseurRepository->findOneBySomeField($id) ;
            $fournisseur->setGroup($updatefournisseur->getNom());
            $this->em->flush();
            } catch (Exception $e) {
                      return 1 ; //$e->getMessage()
                }
        return 0 ;    
            
        }
    }
   
    
   /**
    *  
    */   
    public function Create($Marque) 
    { 
  	    if( $this->FournisseurRepository->findOneFournisseur($Marque->getFournisseur()) != 1) 
  	    {
        	  try {
  	                $fournisseur = new Fournisseur ;
                    $fournisseur->setNom($Marque->getFournisseur()) ;
                    $this->em->persist($fournisseur) ;
                    $this->em->flush() ;
                  } catch (Exception $e) {
                      return -1 ; //$e->getMessage()
                      } 
  	         return 0 ;
  	         } else {
                 return 1 ;
  	    }
  	}
}    
        