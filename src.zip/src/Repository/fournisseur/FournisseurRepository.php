<?php
namespace App\Repository\fournisseur;
use App\Entity\Fournisseur;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;



use Doctrine\ORM\EntityManagerInterface ;


/**
 * @method Tva|null find($id, $lockMode = null, $lockVersion = null)
 * @method Tva|null findOneBy(array $criteria, array $orderBy = null)
 * @method Tva[]    findAll()
 * @method Tva[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class FournisseurRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry, EntityManagerInterface $em)
    {
        parent::__construct($registry, Fournisseur::class);
        $this->em = $em ;
    }

    // /**
    //  * @return Fournisseur[] Returns an array of Fournisseur objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('f.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    
    public function findOneBySomeField($value): ?Fournisseur
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.id = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    
    
    
   /**
    * @return count id
    */
    public function findByCountId(): int
    {
        return $this->createQueryBuilder('f')
             ->select('count(f.id)')
             ->getQuery()
             ->getSingleScalarResult();
    }   

  /**
   * @return Fournisseur[] Returns an array of Prod objects
   */
   public function findOneFournisseur($fournisseur)
   {
        return $this->createQueryBuilder('f')
             ->andWhere('f.nom = :val')
             ->setParameter('val', $fournisseur)
             ->getQuery()
             ->getResult()
            ;
   }
    
    

    public function findById($id): array
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.id = :val')
            ->setParameter('val', $id)
            ->getQuery()
            ->getResult()
            
        ;
    }
    
    
    public function findByList(): array
    {
        return $this->createQueryBuilder('f')
            ->getQuery()
            ->getResult()
        ;
    }
    
    
    public function findAllPagin($ascdesc, $limit, $offset): array
    {
        return $this->createQueryBuilder('fournisseur')
            ->orderBy('fournisseur.id', 'ASC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }
                    
   public function findOneFournisseurBefUpdate($fournisseur, $idfournisseur): int
    {
       return $this->createQueryBuilder('fournisseur')
            ->select('count(fournisseur.id)') 
            ->andWhere('fournisseur.nom = :val')
            ->andWhere('fournisseur.id != :val2')
            ->setParameter('val', $fournisseur)
            ->setParameter('val2', $idfournisseur)
            ->getQuery()
            ->getSingleScalarResult();
    }
    
    
    
    
    
   /**
    * 
    * retourne un array derniers sous groupe enregistrés
    */
    public function findByLastFournisseurInsert(): array 
    {
        $count = $this->findByCountId() ;
        $offset = $count - 30 ;
        if($offset < 0) {
            $offset = 0; 
        }
        $limit = $offset + 30 ;
        
        return $this->createQueryBuilder('f')
            ->orderBy('f.id', 'ASC')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
     }


   /**
    *  
    * retourne un tableau issue d'une requête sur fournisseur
    */
    public function findFileFournisseurById($idfournisseur): array 
    {
        return $this->createQueryBuilder('fournisseur')            
            ->andWhere('fournisseur.id = :val')
            ->setParameter('val', $idfournisseur)
            ->getQuery()
            ->getResult()
            ;
            
    }

    

}
