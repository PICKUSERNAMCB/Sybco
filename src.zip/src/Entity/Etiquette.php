<?php

namespace App\Entity;

use App\Repository\EtiquetteRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EtiquetteRepository::class)
 */
class Etiquette
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $etiquette;
    
    
    
    /**
     * @ORM\ManyToOne(targetEntity="Groupe",inversedBy="etiquettes")
     * @ORM\JoinColumn(nullable=false)
     */
    private $groupe;

    
    public function __construct()
    {
        $this->critertxts = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEtiquette(): ?string
    {
        return $this->etiquette;
    }

    public function setEtiquette(string $etiquette): self
    {
        $this->etiquette = $etiquette;

        return $this;
    }

    public function getGroupe(): ?Groupe
    {
        return $this->groupe;
    }

    public function setGroupe(?Groupe $groupe): self
    {
        $this->groupe = $groupe;

        return $this;
    }
    
    public function __toString(): string
    {
        return $this->getId().'=>'.$this->getEtiquette();
    }

    
}
