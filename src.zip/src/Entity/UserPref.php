<?php

namespace App\Entity;

use App\Repository\UserPrefRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=UserPrefRepository::class)
 */
class UserPref
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $list_limit;
    
    
    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    private $email;
    
    
    /**
     * @ORM\Column(type="string", length=10, nullable=true)
     */
    private $ascdesc;


    
    


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getListLimit(): ?int
    {
        return $this->list_limit;
    }

    public function setListLimit(?int $list_limit): self
    {
        $this->list_limit = $list_limit;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(?string $email): self
    {
        $this->email = $email;

        return $this;
    }
    
    public function getAscDesc(): ?string
    {
        return $this->email;
    }

    public function setAscDesc(?string $ascdesc): self
    {
        $this->ascdesc = $ascdesc;

        return $this;
    }
    
    
    
    
}
