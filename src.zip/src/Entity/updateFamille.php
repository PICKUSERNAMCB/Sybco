<?php
namespace App\Entity;

class updateFamille
{
    private $groupe ;
    
    public function getGroupe()
    {
        return $this->groupe;
    }
    
    public function setGroupe($groupe)
    {
        $this->groupe = $groupe;
    }
    
    
    // ...
}