<?php

namespace App\Entity;
use Doctrine\ORM\Mapping as ORM;


 
 /**
   * @ORM\Entity
   * @ORM\Table(name="prod")
   */
 
class Prod
{
   /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

   /**
     * @ORM\Column(type="string", length=13, nullable=false)
     */
    private $gtin;

   
   /**
     * @ORM\ManyToOne(targetEntity=Fournisseur::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $fournisseur;
    
    
    /**
     * @ORM\ManyToOne(targetEntity=Etiquette::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $etiquette;
    
   /**
     * @ORM\Column(type="text", nullable=false)
     */
    private $description;
    
    /**
     * @ORM\Column(type="text", nullable=false)
     */
    private $pretext;
    
    
   /**
     * @ORM\Column(type="text", nullable=false)
     */
    private $descriptioncomplete;
    
   /**
     * @ORM\ManyToOne(targetEntity=Tva::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $typetva;
    
   /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $stock;
    
   /**
     * @ORM\Column(type="decimal", precision=5, scale=2, nullable=false)
     */
    private $prixttc;
    
   /**
     * @ORM\Column(type="decimal", precision=4, scale = 2, nullable=false)
     */
    private $avis;
    
   /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $nbravis;
    

   /**
     * @ORM\Column(type="string", length=60, nullable=false)
     */
    private $miniatureUrl;
    
    
   



    
    public function getId(): ?int
    {
        return $this->id;
    }

    public function getGTIN(): ?string
    {
        return $this->gtin;
    }

    public function setGTIN(?string $gtin): self
    {
        $this->gtin = $gtin;

        return $this;
    }

   public function getFournisseur(): ?Fournisseur
    {
        return $this->fournisseur;
    }

    public function setFournisseur(?Fournisseur $fournisseur): self
    {
        $this->fournisseur = $fournisseur;

        return $this;
    }
    
    public function getEtiquette(): ?Etiquette
    {
        return $this->etiquette;
    }
    
    public function setEtiquette(?Etiquette $etiquette): self
    {
        $this->etiquette = $etiquette;

        return $this;
    }
    
    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description ;

        return $this;
    }
    
     public function getPretext(): ?string
    {
        return $this->pretext;
    }

    public function setPretext(?string $pretext): self
    {
        $this->pretext = $pretext ;

        return $this;
    }
    
    
    
    
    public function getDescriptionComplete(): ?string
    {
        return $this->descriptioncomplete;
    }

    public function setDescriptionComplete(?string $descriptioncomplete): self
    {
        $this->descriptioncomplete = $descriptioncomplete ;

        return $this;
    }
    
    public function getTypeTva(): ?Tva
    {
        return $this->typetva;
    }

    public function setTypeTva(?Tva $tva): self
    {
        $this->typetva = $tva;

        return $this;
    }
    
    public function getStock(): ?int
    {
        return $this->stock;
    }

    public function setStock(?int $stock): self
    {
        $this->stock = $stock;

        return $this;
    }
    
    public function getPrixTTC(): ?float
    {
        return $this->prixttc;
    }

    public function setPrixTTC(?float $prixttc): self
    {
        $this->prixttc = $prixttc;

        return $this;
    }
    
    public function getAvis(): ?float
    {
        return $this->avis;
    }

    public function setAvis(?float $avis): self
    {
        $this->avis = $avis;

        return $this;
    }
    
    public function getNbrAvis(): ?int
    {
        return $this->nbravis;
    }

    public function setNbrAvis(?int $nbravis): self
    {
        $this->nbravis = $nbravis;

        return $this;
    }
    
    public function setMiniatureUrl(?string $miniatureUrl): self
    {
        $this->miniatureUrl = $miniatureUrl;

        return $this;
    }
    
    public function getMiniatureUrl(): ?string
    {
        return $this->miniatureUrl;
    }
    
 }
    
    
