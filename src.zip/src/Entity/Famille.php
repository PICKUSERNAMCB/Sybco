<?php
namespace App\Entity;

class Famille
{
    private $lastgroupe;
    private $groupe ;
    
    public function getLastgroupe()
    {
        return $this->lastgroupe;
    }
    
    public function setLastgroupe($lastgroupe)
    {
        $this->lastgroupe = $lastgroupe;
    }
    
    public function getGroupe()
    {
        return $this->groupe;
    }
    
    public function setGroupe($groupe)
    {
        $this->groupe = $groupe;
    }
    
    
    // ...
}