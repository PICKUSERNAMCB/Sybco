<?php

namespace App\Entity;

use App\Repository\TvaRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=TvaRepository::class)
 */
class Tva
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="float")
     */
    private $type;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getType(): ?float
    {
        return $this->type;
    }

    public function setType(float $type): self
    {
        $this->type = $type;

        return $this;
    }
    
    
    public function __toString(): string
    {
        return $this->getId()."=>".$this->getType() ;    
    }
    
    
}
