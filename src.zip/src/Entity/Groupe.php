<?php
namespace App\Entity ; 
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM ;




 /**
   * @ORM\Entity
   * @ORM\Table(name="groupe")
   */
 
class Groupe 
 {
                                                                                                
 /**
   * @ORM\Column(name="id", type="integer")
   * @ORM\Id
   * @ORM\GeneratedValue(strategy="AUTO")
   */
    private $id ;
                                                                                       
  /**
    * @ORM\Column(name="groupe", type="string", length=50 )
    */
     private $groupe ;

     /**
      * @ORM\OneToMany(targetEntity=Etiquette::class, mappedBy="groupe")
      */
     private $etiquettes;

     public function __construct()
     {
         $this->etiquettes = new ArrayCollection();
     }

     
    
     
   /**
     * return integer
     */
     public function getId()
     {
           return $this->id  ;
      }
                                                                                                      
    /**
      * @param string $groupe
      * @return Group
      */
       public function setGroup($groupe)
       {
            return $this->groupe = $groupe ;
        }
                                                                                                      
      /**
        * return string
        */
        public function getGroup()
        {
              return $this->groupe  ;
         }

        /**
         * @return Collection|Etiquette[]
         
        public function getEtiquettes(): Collection
        {
            return $this->etiquettes;
        }

        public function addEtiquette(Etiquette $etiquette): self
        {
            if (!$this->etiquettes->contains($etiquette)) {
                $this->etiquettes[] = $etiquette;
                $etiquette->setGroupe($this);
            }

            return $this;
        }

        public function removeEtiquette(Etiquette $etiquette): self
        {
            if ($this->etiquettes->removeElement($etiquette)) {
                // set the owning side to null (unless already changed)
                if ($etiquette->getGroupe() === $this) {
                    $etiquette->setGroupe(null);
                }
            }

            return $this;
        }
         
      */
      public function __toString(): string
      {
        return $this->getid()."=>".$this->getGroup() ;    
      }
  }      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      

  
  
   