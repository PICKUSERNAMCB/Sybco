<?php
// src/pagin/paginApp.php
namespace App\Pagin ;



class PaginApp 
{

    
    
    public function Follow($url, $ascdesc, $limit, $offset, $Count): array 
    {
      $Follow = [ 'active' => NULL,
                  'url' => NULL,
                  'ascdesc' => NULL,
                  'limit' => NULL,
                  'offset' => NULL,
                  'page' => NULL,
                  ] ;
       
       if($offset + $limit - $Count < $limit) 
       {
          $Follow['active'] = 1;
          $Follow['url'] = $url ;
          $Follow['ascdesc'] = $ascdesc ;
          $Follow['limit'] = $limit ;
          $Follow['offset'] = $offset ; /* + $limit */
          $Follow['page'] = intdiv($offset, $limit) ;
          
          } else {
             $Follow['active'] = 0;
          }
        return $Follow ;  
    }





    public function Previous($url, $ascdesc, $limit, $offset): array 
    {
        $Previous = [ 'active' => NULL,
                       'url' => NULL,
                       'description' => NULL,
                       'ascdesc' => NULL,
                       'limit' => NULL,
                       'offset' => NULL,
                       'page' => NULL
                      ] ;     
                      
                      
        if($offset - $limit >= 0) 
        {
          $Previous['active'] = 1;
          $Previous['url'] = $url ;
          $Previous['ascdesc'] = $ascdesc ;
          $Previous['limit'] = $limit ;
          $Previous['offset'] = $offset - $limit ;
          $Previous['page'] = intdiv(($offset - $limit), $limit) ;

           } else {
            $Previous['active'] = 0;
          }
        return $Previous ;  
    }
    
    
    public function Pagin($url, $ascdesc, $limit, $offset, $count): array 
    {
          
          return [
            'Follow' => $this
                ->Follow($url,$ascdesc, $limit, $offset+$limit, $count
                             ),
            'Follow1' => $this
                ->Follow($url, $ascdesc, $limit, $offset, $count
                             ),
            'Follow2' => $this
                ->Follow($url, $ascdesc, $limit, $offset+$limit, $count
                           ),
            'Follow3' => $this
                ->Follow($url, $ascdesc, $limit, $offset+($limit*2), $count
                          ),
            'Previous' => $this
                ->Previous($url, $ascdesc, $limit, $offset),
            'Previous1' => $this
                ->Previous($url, $ascdesc, $limit, $offset),
            'Previous2' => $this
                ->Previous($url, $ascdesc, $limit, $offset-$limit),
            'Previous3' => $this
                ->Previous($url , $ascdesc, $limit, $offset-($limit*2)),
       ];
    }

}   
   
   
   
