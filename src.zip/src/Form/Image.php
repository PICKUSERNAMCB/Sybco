<?php
namespace App\Form;

class Image
{
    private $miniature ;
    
    public function getMiniature()
    {
        return $this->miniature ;
    }
    
    public function setMiniature($miniature)
    {
        $this->miniature = $miniature;
    }
    

    
    
    
    // ...
}