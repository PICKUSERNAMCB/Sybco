<?php
namespace App\Form;

class updateArticle
{
    private $id ;
    private $controlcode ;
    private $code;
    private $groupe ;
    private $description ;
    private $notice ;
    private $stock;
    private $tva ;
    private $prixTTC ;
    private $avis ;
   
    public function getId()
    {
        return $this->id ;  
    }

    public function getControlCode()
    {
        return $this->controlcode;
    }
    
    public function setControlCode($controlcode)
    {
        $this->controlcode = $controlcode;
    }
    


    public function getCode()
    {
        return $this->code;
    }
    
    public function setCode($code)
    {
        $this->code = $code;
    }
    
    public function getGroupe()
    {
        return $this->groupe;
    }
    
    public function setGroupe($groupe)
    {
        $this->groupe = $groupe;
    }
    
    
    public function getFournisseur()
    {
        return $this->fournisseur;
    }
    
    public function setFournisseur($fournisseur)
    {
        $this->fournisseur = $fournisseur;
    }
    
    public function getDescription()
    {
        return $this->description;
    }
    
    public function setDescription($description)
    {
        $this->description = $description;
    }
    
    public function getStock()
    {
        return $this->stock;
    }
    
    public function setStock($stock)
    {
        $this->stock = $stock;
    }
    
    public function getTva()
    {
        return $this->tva;
    }
    
    public function setTva($tva)
    {
        $this->tva = $tva;
    }
    
    public function setPrixTTC($prixTTC)
    {
        $this->prixTTC = $prixTTC;
    }
    
    public function getPrixTTC()
    {
        return $this->prixTTC;
    }
    
    public function setAvis($avis)
    {
        $this->avis = $avis;
    }
    
    public function getAvis()
    {
        return $this->avis;
    }
    
    
    
    
    // ...
}