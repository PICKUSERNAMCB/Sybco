<?php
namespace App\Form;
use App\Repository\product\GroupeRepository ;
use App\Repository\product\EtiquetteRepository ;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType ; 
use Symfony\Component\Validator\Constraints\File ; 
use Symfony\Component\Validator\Constraints\Regex ;
use App\Form\Sfamille ; 


class EtiquetteType extends AbstractType
{
    
    protected $GroupFile ;
    
    public function __construct(GroupeRepository $group, EtiquetteRepository $er) 
    {
        $this->GroupeRepository = $group ;
        $this->EtiquetteRepository = $er ; 
    }


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $groupes = $this->GroupeRepository->findByList() ;
        $groupe = array();
        foreach($groupes as $group) 
        {
          $groupe[$group->getGroup()] = $group->getId() ;
        }
        $histo = array() ; 
        $lastlessergroupes = $this->EtiquetteRepository->findByLastLesserGroupInsert();
        foreach($lastlessergroupes as $lastlessergroupe) 
        {
           $histo[$lastlessergroupe->getEtiquette()] = $lastlessergroupe->getId() ;       
        } 
        $builder
            ->add('lastlessergroupe', ChoiceType::class, [ 'choices'   => $histo])
            ->add('groupe', ChoiceType::class, [ 'choices'   => $groupe ])
            ->add('etiquette', TextType::class, array(
                                          'required' => true, 
                                          'attr' =>  ['maxlength' => 25])); 
    } 
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Sfamille::class,
          ]);
    }
}