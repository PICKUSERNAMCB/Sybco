<?php
namespace App\Form;
use App\Repository\product\EtiquetteRepository ;

use App\Repository\fournisseur\FournisseurRepository ;

use App\Repository\config\TvaRepository ;
use App\Repository\product\ProdRepository;
use App\Form\Article ;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;


use Symfony\Component\Validator\Constraints\File ; 
use Symfony\Component\Validator\Constraints\Regex ;



use Symfony\Component\Form\Extension\Core\Type as Form;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;





class ArticleType extends AbstractType
{
    
  
    
    public function __construct(EtiquetteRepository $etiquette, TvaRepository $tva, FournisseurRepository $fournisseur, ProdRepository $prod) 
    {
        $this->EtiquetteRepository = $etiquette;
        $this->TvaRepository = $tva ;
        $this->FournisseurRepository = $fournisseur ;
        $this->ProdRepository = $prod ;
    }


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        
        $lessergroupes = $this->EtiquetteRepository->Read();
        $lessergroupe = array();
        foreach($lessergroupes as $lessergroup) {
          
          
          $lessergroupe['Sous-famille > '.$lessergroup->getEtiquette().' (famille : '.explode("=>", $lessergroup->getGroupe())[1].')'] = $lessergroup->getId() ;
        
        }
        $fournisseurs = $this->FournisseurRepository->findByList();
        $fournisseur = array();
        foreach($fournisseurs as $fourniture) {
          $fournisseur[$fourniture->getNom()] = $fourniture->getId() ;
        }
        
        
        $taxes = $this->TvaRepository->findByList() ;
        $tva = array();
        foreach($taxes as $taxe) {
          $tva[$taxe->getType()] = $taxe->getId() ;
        }
        
        $histo = array() ; 
        $lastproducts = $this->ProdRepository->findByLastproductInBase();
        foreach($lastproducts as $lastproduct) {
           $histo[$lastproduct->getGTIN()." ".$lastproduct->getDescription()] = $lastproduct->getid() ;       
        } 
        
        
        $stock = array();
        for($i = 0 ; $i < 500 ; $i++) {
         	$stock[$i] = $i ;
        }
        
        
        $builder
            ->add('lastprod', ChoiceType::class, [ 'choices' => $histo])
            ->add('controlcode', CheckboxType::class, [ 'required'   => false ])
            ->add('code', TextType::class, array(
                                          'required' => true,  
                                          'attr' =>  ['maxlength' => 13]))
            ->add('etiquette', ChoiceType::class, [ 'choices'   => $lessergroupe ])
            ->add('fournisseur', ChoiceType::class, [ 'choices'   => $fournisseur ])
            ->add('description', TextType::class, array(
                                          'required' => true, 
                                          'attr' =>  ['maxlength' => 45],
                                          )) 
            ->add('miniature', FileType::class, [
                                          // unmapped means that this field is not associated to any entity property
                                          'mapped' => false,
                                          'required' => true,
                                          'constraints' => [
                                             new File([
                                                   'maxSize' => '1024k',
                                                   'mimeTypes' => [
                                                   'image/jpeg',
                                                   'image/png',
                                                    ],
                                          'mimeTypesMessage' => 'Veuillez entrer un fichier au format demandé',
                                          ])],])
            ->add('stock', ChoiceType::class, [ 'choices'   => $stock ])
            ->add('tva', ChoiceType::class, [ 'choices'   => $tva ])
            ->add('prixttc', MoneyType::class, array(
                                          'required' => true))
            ->add('avis', CheckboxType::class, [ 'required'   => false ]);
            
    } 
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Article::class,
          ]);
    }
}