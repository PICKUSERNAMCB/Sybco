<?php
namespace App\Form;

class Sfamille
{
    private $lastlessergroupe;
    private $groupe;
    private $etiquette ;
    

    public function getLastLessergroupe()
    {
        return $this->lastlessergroupe;
    }
    
    public function setLastLessergroupe($lastlessergroupe)
    {
        $this->lastlessergroupe = $lastlessergroupe;
    }

    public function getGroupe()
    {
        return $this->groupe;
    }
    
    public function setGroupe($groupe)
    {
        $this->groupe = $groupe;
    }
    
    public function getEtiquette()
    {
        return $this->etiquette;
    }
    
    public function setEtiquette($etiquette)
    {
        $this->etiquette = $etiquette;
    }
    
    
    // ...
}