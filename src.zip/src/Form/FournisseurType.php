<?php
namespace App\Form;
use App\Repository\fournisseur\FournisseurRepository;
use App\Entity\Fournisseur ;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;


use Symfony\Component\Validator\Constraints\File ; 
use Symfony\Component\Validator\Constraints\Regex ;


class FournisseurType extends AbstractType
{
    
  
    
    public function __construct(FournisseurRepository $fournisseur) 
    {
        $this->FournisseurRepository = $fournisseur ;
    }


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $histo = array() ; 
        $lastfournisseurs = $this->FournisseurRepository->findByLastfournisseurInsert(); 
        foreach($lastfournisseurs as $lastfournisseur) 
        {
            $histo[$lastfournisseur->getNom()] = $lastfournisseur->getId() ;       
        }
        $builder
            ->add('lastfournisseur', ChoiceType::class, [ 'choices' => $histo])
            ->add('fournisseur', TextType::class );

    } 
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Marque::class,
          ]);
    }
}