<?php
namespace App\Form;
use App\Form\Image ;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\FileType;


use Symfony\Component\Validator\Constraints\File ; 
use Symfony\Component\Validator\Constraints\Regex ;


class ImageType extends AbstractType
{
    
  
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        
        $builder
            ->add('miniature', FileType::class, [
                                          // unmapped means that this field is not associated to any entity property
                                          'mapped' => false,
                                          'required' => true,
                                          'constraints' => [
                                             new File([
                                                   'maxSize' => '1024k',
                                                   'mimeTypes' => [
                                                   'image/jpeg',
                                                   'image/png',
                                                    ],
                                          'mimeTypesMessage' => 'Veuillez entrer un fichier au format demandé',
                                          ])],]) ;
    } 
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Image::class,
          ]);
    }
}