<?php
namespace App\Form;

class updateSFamille
{
    private $groupe;
    private $etiquette ;
    

    public function getGroupe()
    {
        return $this->groupe;
    }
    
    public function setGroupe($groupe)
    {
        $this->groupe = $groupe;
    }
    
    public function getEtiquette()
    {
        return $this->etiquette;
    }
    
    public function setEtiquette($etiquette)
    {
        $this->etiquette = $etiquette;
    }
    
    
    // ...
}