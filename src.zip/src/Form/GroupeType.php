<?php
namespace App\Form;
use App\Repository\product\GroupeRepository;
use App\Entity\Famille ;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;


use Symfony\Component\Validator\Constraints\File ; 
use Symfony\Component\Validator\Constraints\Regex ;


class GroupeType extends AbstractType
{
    
  
    
    public function __construct(GroupeRepository $groupe) 
    {
        $this->GroupeRepository = $groupe ;
    }


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $histo = array() ; 
        $lastgroupes = $this->GroupeRepository->findByLastgroupInsert(); 
        foreach($lastgroupes as $lastgroupe) 
        {
            $histo[$lastgroupe->getGroup()] = $lastgroupe->getId() ;       
        }
        $builder
               ->add('lastgroupe', ChoiceType::class, [ 'choices' => $histo])
               ->add('groupe', TextType::class );

    } 
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Famille::class,
          ]);
    }
}