<?php
namespace App\Form;

use App\Form\updateArticle ;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;

use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;

use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;



class updateArticleType extends AbstractType
{
    
  
    
    

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
       
        
        
       
       $builder
        
            ->add('controlcode', CheckboxType::class, [ 'required'   => false ])
            ->add('code', TextType::class, array(
                                          'required' => true,  
                                          'attr' =>  ['maxlength' => 13]))
            ->add('description', TextType::class, array(
                                          'required' => true, 
                                          'attr' =>  ['maxlength' => 50])) 
            ->add('prixttc', MoneyType::class, array(
                                          'required' => true))
            ->add('avis', CheckboxType::class, [ 'required'   => false ]);
            
    } 
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => updateArticle::class,
          ]);
    }
}