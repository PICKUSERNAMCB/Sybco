<?php
namespace App\Form;

class Search
{
    
    
    // ...
}