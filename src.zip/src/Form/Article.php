<?php
namespace App\Form;

class Article
{
    private $id ;
    private $lastprod ;
    private $controlcode ;
    private $code;
    private $groupe ;
    private $etiquette ;
    private $fournisseur ;
    private $description ;
    private $miniature ; 
    private $notice ;
    private $stock;
    private $tva ;
    private $prixTTC ;
    private $avis ;
    private $img ; 
    
    public function getId()
    {
        return $this->id ;  
    }
    
    public function getLastprod()
    {
        return $this->lastprod;
    }
    
    public function setLastprod($lastprod)
    {
        $this->lastprod = $lastprod;
    }
    

    public function getControlCode()
    {
        return $this->controlcode;
    }
    
    public function setControlCode($controlcode)
    {
        $this->controlcode = $controlcode;
    }
    
    public function getCode()
    {
        return $this->code;
    }
    
    public function setCode($code)
    {
        $this->code = $code;
    }
    
    public function getGroupe()
    {
        return $this->groupe;
    }
    
    public function setGroupe($groupe)
    {
        $this->groupe = $groupe;
    }
    
    public function getEtiquette()
    {
        return $this->etiquette;
    }
    
    public function setEtiquette($etiquette)
    {
        $this->etiquette = $etiquette;
    }
    
    public function getFournisseur()
    {
        return $this->fournisseur;
    }
    
    public function setFournisseur($fournisseur)
    {
        $this->fournisseur = $fournisseur;
    }
    
    public function getDescription()
    {
        return $this->description;
    }
    
    public function setDescription($description)
    {
        $this->description = $description;
    }
    
    public function getMiniature()
    {
        return $this->img;
    }
    
    public function setMiniature($miniature)
    {
        $this->img = $miniature;
    }
    
    public function getNotice()
    {
        return $this->notice;
    }
    
    public function setNotice($notice)
    {
        $this->img = $notice;
    }
    
    
        
    public function getStock()
    {
        return $this->stock;
    }
    
    public function setStock($stock)
    {
        $this->stock = $stock;
    }
    
    public function getTva()
    {
        return $this->tva;
    }
    
    public function setTva($tva)
    {
        $this->tva = $tva;
    }
    
    public function setPrixTTC($prixTTC)
    {
        $this->prixTTC = $prixTTC;
    }
    
    public function getPrixTTC()
    {
        return $this->prixTTC;
    }
    
    public function setAvis($avis)
    {
        $this->avis = $avis;
    }
    
    public function getAvis()
    {
        return $this->avis;
    }
    
    public function getImg()
    {
        return $this->img;
    }
    
    public function setImg($img)
    {
        $this->img = $img;
    }
    
    
    
    
    
    // ...
}